import React from "react";

const UserReview = () => {
  return <div>UserReview</div>;
};

export default UserReview;
